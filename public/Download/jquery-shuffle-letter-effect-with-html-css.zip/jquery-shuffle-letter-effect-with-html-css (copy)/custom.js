$(function(){
	
	// container is the DOM element;
	// userText is the textbox
	
	var container = $("#title")
		userText = $('#userText'); 
	
	// Shuffle the contents of container
	container.shuffleLetters();

	// Bind events
	userText.click(function () {
		
	  userText.val("");
	  
	});

	$('.try-it').click(function(e) {	
		container.shuffleLetters({
			"text": userText.val()
		});
	});

	// Leave a 4 second pause

	setTimeout(function(){
		
		// Shuffle the container with custom text
		container.shuffleLetters({
			"text": "Test it for yourself!"
		});
		
		userText.val("type anything").fadeIn();
		
		$('.try-it').css('display','inline-block');

		
	},4000);
	
});
