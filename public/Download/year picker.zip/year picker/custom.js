$("#datepicker").datepicker({
   format: "yyyy",
   viewMode: "years", 
   minViewMode: "years"
});