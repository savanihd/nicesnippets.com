$("#datepicker").datepicker({
    format: "MM yyyy",
    viewMode: "years", 
    minViewMode: "months"
});